def run_daily_predictions():
    print("Running HR predictions...")
