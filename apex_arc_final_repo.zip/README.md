# Apex Arc Engine

MLB HR Prediction Engine using Statcast + overlays.