# Installation

1. Clone the repo
2. Run `python run_daily_simulation.py`