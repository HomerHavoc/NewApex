# Quickstart

Just run the simulation script to generate outputs.