# Apex Arc Engine

Daily MLB HR simulation and betting optimization framework.